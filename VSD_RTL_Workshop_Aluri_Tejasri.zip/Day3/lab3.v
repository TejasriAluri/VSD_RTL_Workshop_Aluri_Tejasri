// Placeholder Verilog code
module lab3();
endmodule
