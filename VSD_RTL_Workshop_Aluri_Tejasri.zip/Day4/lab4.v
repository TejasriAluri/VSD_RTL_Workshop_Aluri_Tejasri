// Placeholder Verilog code
module lab4();
endmodule
