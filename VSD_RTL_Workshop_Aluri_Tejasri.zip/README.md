# VSD RTL Workshop — Aluri Tejasri

Welcome to the **VSD RTL Workshop** repository curated by **Aluri Tejasri**.  
This repository contains structured lab exercises and tasks for a 5-day RTL workshop using Verilog.

## Repository Structure

- **Day1 → Day5**: Each folder contains day-wise lab exercises with placeholder Verilog files and testbenches.
- **README.md (per day)**: Provides a clean space to add lab instructions and notes.
- **.gitignore**: Standard ignores for Verilog/EDA projects.

> **Note:** All lab files are placeholders. Replace with actual RTL and testbench code as you progress through the workshop.

## How to Use

1. Clone the repository:

```bash
git clone <repository-url>
cd VSD_RTL_Workshop_Aluri_Tejasri
```

2. Navigate to the day folder you want to work on:

```bash
cd Day1
```

3. Open `labX.v` and `testbenchX.v` to start coding or simulation exercises.
