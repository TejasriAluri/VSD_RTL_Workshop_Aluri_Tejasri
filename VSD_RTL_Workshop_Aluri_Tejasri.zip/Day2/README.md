# Day 2 — Lab Exercises

This folder contains the lab files and testbench for **Day 2** of the RTL workshop.

## Lab Files

- `lab2.v` — Placeholder Verilog code
- `testbench2.v` — Placeholder testbench

## Tasks

1. Add your lab instructions here.
2. Implement RTL designs as per workshop guidelines.
3. Run simulations and verify outputs.
